create definer = root@`%` trigger trg_before_update_warehouse_status
    before update
    on warehouse
    for each row
BEGIN
    -- 所有变量声明必须在 BEGIN 后面第一部分
    DECLARE capacity_percentage DECIMAL(5,2);
    DECLARE earliest_date DATE;
    
    IF NEW.status = '维护' THEN
        -- 如果状态已被设置为“维护”，不修改状态，直接保留原状态
        SET NEW.status = NEW.status;
    ELSEIF NEW.cur_capacity IS NULL OR NEW.cur_capacity = 0 THEN
        SET NEW.status = '空置';
    ELSE
        SET capacity_percentage = (NEW.cur_capacity / NEW.max_capacity) * 100;
        IF capacity_percentage >= 95 THEN
            SET NEW.status = '满仓';
        ELSE
            -- 查询该仓库中所有库存记录中最早的入库日期
            SELECT MIN(entry_date) INTO earliest_date
            FROM inventory
            WHERE warehouse_id = NEW.id;
            
            IF earliest_date IS NOT NULL AND DATEDIFF(CURDATE(), earliest_date) >= 30 THEN
                SET NEW.status = '临期预警';
            ELSE
                SET NEW.status = '正常';
            END IF;
        END IF;
    END IF;
END;

