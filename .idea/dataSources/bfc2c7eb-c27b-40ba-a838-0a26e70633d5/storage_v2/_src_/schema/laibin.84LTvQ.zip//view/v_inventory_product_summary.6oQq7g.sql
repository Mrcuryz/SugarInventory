create definer = root@`%` view v_inventory_product_summary as
select `i`.`warehouse_id`        AS `warehouse_id`,
       `p`.`id`                  AS `product_id`,
       `p`.`product_name`        AS `product_name`,
       `p`.`packaging_method`    AS `packaging_method`,
       `p`.`weight_per_piece`    AS `weight_per_piece`,
       sum(`i`.`total_quantity`) AS `total_quantity`,
       min(`i`.`entry_date`)     AS `first_entry_date`
from (`laibin`.`inventory` `i` join `laibin`.`product` `p` on ((`i`.`product_id` = `p`.`id`)))
group by `i`.`warehouse_id`, `p`.`id`, `p`.`product_name`, `p`.`weight_per_piece`;

