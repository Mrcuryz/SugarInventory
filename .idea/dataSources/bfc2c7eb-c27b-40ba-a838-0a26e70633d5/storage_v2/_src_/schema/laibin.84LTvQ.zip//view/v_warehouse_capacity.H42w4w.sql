create definer = root@`%` view v_warehouse_capacity as
select `w`.`id`                                  AS `warehouse_id`,
       `w`.`warehouse_id`                        AS `warehouse_code`,
       `w`.`status`                              AS `status`,
       `w`.`cur_capacity`                        AS `cur_capacity`,
       `w`.`max_capacity`                        AS `max_capacity`,
       (`w`.`cur_capacity` / `w`.`max_capacity`) AS `capacity_percentage`,
       min(`i`.`entry_date`)                     AS `first_entry_date`
from (`laibin`.`warehouse` `w` join `laibin`.`inventory` `i` on ((`i`.`warehouse_id` = `w`.`id`)))
group by `w`.`id`;

