create definer = root@`%` view v_warehouse_capacity as
select `w`.`id`                                  AS `warehouse_id`,
       `w`.`warehouse_id`                        AS `warehouse_code`,
       `w`.`status`                              AS `status`,
       `w`.`cur_capacity`                        AS `cur_capacity`,
       `w`.`max_capacity`                        AS `max_capacity`,
       (`w`.`cur_capacity` / `w`.`max_capacity`) AS `capacity_percentage`,
       min(`i`.`entry_date`)                     AS `first_entry_date`
from (`laibin`.`warehouse` `w` join `laibin`.`inventory` `i` on ((`i`.`warehouse_id` = `w`.`id`)))
group by `w`.`id`;

-- comment on column v_warehouse_capacity.warehouse_id not supported: 仓库ID

-- comment on column v_warehouse_capacity.warehouse_code not supported: 仓库编号

-- comment on column v_warehouse_capacity.status not supported: 仓库状态

-- comment on column v_warehouse_capacity.cur_capacity not supported: 当前存量

-- comment on column v_warehouse_capacity.max_capacity not supported: 最大容量

-- comment on column v_warehouse_capacity.first_entry_date not supported: 入库日期（生产日期）

