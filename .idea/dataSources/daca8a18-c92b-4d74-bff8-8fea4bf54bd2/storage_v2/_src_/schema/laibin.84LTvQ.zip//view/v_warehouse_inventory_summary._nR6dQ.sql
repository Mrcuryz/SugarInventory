create definer = root@`%` view v_warehouse_inventory_summary as
select `i`.`warehouse_id`    AS `warehouse_id`,
       `p`.`id`              AS `product_id`,
       `p`.`product_name`    AS `product_name`,
       `i`.`entry_date`      AS `entry_date`,
       sum(`i`.`quantity`)   AS `total_quantity`,
       min(`i`.`entry_date`) AS `first_entry_date`
from (`laibin`.`inventory` `i` join `laibin`.`product` `p` on ((`i`.`product_id` = `p`.`id`)))
group by `i`.`warehouse_id`, `p`.`id`, `p`.`product_name`, `i`.`entry_date`;

-- comment on column v_warehouse_inventory_summary.warehouse_id not supported: 库位ID

-- comment on column v_warehouse_inventory_summary.product_id not supported: 产品ID

-- comment on column v_warehouse_inventory_summary.product_name not supported: 产品名称

-- comment on column v_warehouse_inventory_summary.entry_date not supported: 入库日期（生产日期）

-- comment on column v_warehouse_inventory_summary.first_entry_date not supported: 入库日期（生产日期）

